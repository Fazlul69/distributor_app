@extends('master')

@section('content')
   <div class="dashbaord">
      <div class="container">
         <div class="row">
          
            
         </div>
         <div class="row">
            
         </div>
      </div>
   </div>

@endsection