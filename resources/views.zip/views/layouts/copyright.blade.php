<div class="copy">
    <div class="container text-center">
        <p>Copyright &copy; 2024 All Rights Reserved | Developed by <a href="https://github.com/Fazlul69" target="_blank">Fazlul</a></p>
    </div>
</div>